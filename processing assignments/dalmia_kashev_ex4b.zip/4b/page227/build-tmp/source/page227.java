import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page227 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 2b
 *
 * 2 on page 215
 * 2 on page 227
 * 2 on page 236
 * 
 * page215.pde
 */

/*
Exercises
2. Create a typing program to display a different image for each letter on the keyboard.
*/


/* 
 * Images From : http://www.publicdomainpictures.net/view-image.php?image=35513
 */
final int CANVAS_SIZE  = 200;

/*
 * Processing Required
 */

PImage[] letters = new PImage[26];

public void
setup ()
{
    size(CANVAS_SIZE, CANVAS_SIZE);

    for (char i = 'a'; i <= 'z'; i++)
    {
        letters[PApplet.parseInt(i - 'a')] = loadImage(i+".jpg");
    }
}

public void
draw ()
{   
    background(204);
    if ((key >= 'a') && (key <= 'z'))
    {
        image(letters[PApplet.parseInt(key - 'a')], 5, 5);
    }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page227" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
