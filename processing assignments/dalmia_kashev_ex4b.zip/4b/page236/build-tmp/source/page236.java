import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page236 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 2b
 *
 * 2 on page 215
 * 2 on page 227
 * 2 on page 236
 * 
 * page236.pde
 */

/*
Exercises
2. Create two shapes and give each a different relation to the mouse. Design the
behaviors of each shape so that it has one behavior when the mouse is moved
and has another behavior when the mouse is dragged.
*/

final int CANVAS_SIZE  = 200;

/*
 * Processing Required
 */

public void
setup ()
{
    size(CANVAS_SIZE, CANVAS_SIZE);
}

int r = 0, g = 0, v = 0;

public void
draw ()
{   
    background(204);
    fill(color(r, g, 0));
    rect(25, 25, 50, 50);

    fill(color(0, 0, 255));
    rect(100, 100, 50, 50, v);
}


public void mouseDragged() 
{
    r += 1;
    if (r > 255)
    {
        r = 0;
    }

    v -= 1;
    if (v < 0)
    {
        v = 0;
    }
}

public void mouseMoved()
{
    g += 1;
    if (g > 255)
    {
        g = 0;
    }

    v += 1;
    if (v > 50)
    {
        v = 50;
    }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page236" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
