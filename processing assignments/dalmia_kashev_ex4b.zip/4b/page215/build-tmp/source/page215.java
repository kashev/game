import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page215 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 2b
 *
 * 2 on page 215
 * 2 on page 227
 * 2 on page 236
 * 
 * page215.pde
 */

/*
Exercises
2. Invent three unique shapes that behave differently in relation to the mouse. Each
shape\u2019s behavior should change when the mouse is pressed. Relate the form of
each shape to its behavior.
*/

final int CANVAS_SIZE  = 500;

/*
 * Processing Required
 */

public void
setup ()
{
    size(CANVAS_SIZE, CANVAS_SIZE);
}

public void
draw ()
{   
    background(204);
    if (mousePressed == true)
    {
        /* SHAPE 1 */
        fill(color(0, 0, 150));
        triangle(0, 0, CANVAS_SIZE, mouseY, mouseX, CANVAS_SIZE);
        /* SHAPE 2 */
        fill(color(40, 50, 60));
        ellipse(CANVAS_SIZE * 0.5f, CANVAS_SIZE * 0.5f, mouseY, mouseX);
        /* SHAPE 3 */
        fill (color(0, 255, 0));
        rect(mouseX - (CANVAS_SIZE * 0.05f), mouseY- (CANVAS_SIZE * 0.05f), CANVAS_SIZE * 0.1f, CANVAS_SIZE * 0.1f, CANVAS_SIZE* 0.03f);
    }
    else
    {
        /* SHAPE 1 */
        fill(color(0, 0, 150));
        triangle(0, 0, CANVAS_SIZE, mouseX, mouseY, CANVAS_SIZE);
        /* SHAPE 2 */
        fill(color(40, 50, 60));
        ellipse(CANVAS_SIZE * 0.5f, CANVAS_SIZE * 0.5f, mouseX, mouseY);
        /* SHAPE 3 */
        fill (color(255, 0, 0));
        rect(mouseX- (CANVAS_SIZE * 0.05f), mouseY- (CANVAS_SIZE * 0.05f), CANVAS_SIZE * 0.1f, CANVAS_SIZE * 0.1f);
    }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page215" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
