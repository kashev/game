import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page196 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 5b
 *
 * 1 on page 196
 * 1 on page 313
 * 1 on page 320
 * 2 on page 354
 * 
 * page196.pde
 */

/*
Exercises
1. Write a function to draw a shape to the screen multiple times, each at a
different position.
*/

final int CANVAS_SIZE  = 700;


public void
drawShapes (int num, PShape s)
{
    for (int i = 0; i < num; i++)
    {
        shape(s, random(0, CANVAS_SIZE), random(0, CANVAS_SIZE), 20, 20);
    }
}

/*
 * Processing Required
 */

PShape theshape;

public void
setup ()
{
    size(CANVAS_SIZE, CANVAS_SIZE, P2D);
    frameRate(10);
    theshape = createShape(ELLIPSE, 0, 0, 50, 50);
}

public void
draw ()
{   
    drawShapes(5, theshape);
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page196" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
