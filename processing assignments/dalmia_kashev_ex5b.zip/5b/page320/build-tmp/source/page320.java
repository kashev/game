import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page320 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 5b
 *
 * 1 on page 196
 * 1 on page 313
 * 1 on page 320
 * 2 on page 354
 * 
 * page320.pde
 */

/*
Exercises
1. Load a sequence of related images into an array and use them to create a
linear animation.
*/

final int CANVAS_SIZE  = 700;
final int NUM_FRAMES   = 73;
/*
 * Processing Required
 */

PImage imgs [] = new PImage[NUM_FRAMES];
int f = 0;

public void
setup ()
{
    for (int i = 0; i < NUM_FRAMES; i++)
    {
        imgs[i] = loadImage("wow-gif/frame_" + nf(i, 3) + ".gif"); 
    }

    size(imgs[0].width, imgs[0].height);
    frameRate(20);
}

public void
draw ()
{
    image(imgs[f], 0, 0);
    f = (f + 1) % NUM_FRAMES;
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page320" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
