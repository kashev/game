import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page313 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 5b
 *
 * 1 on page 196
 * 1 on page 313
 * 1 on page 320
 * 2 on page 354
 * 
 * page196.pde
 */

/*
Exercises
1. Create an array to store the y-coordinates of a sequence of shapes. Draw each shape
inside draw() and use the values from the array to set the y-coordinate of each.
*/

final int CANVAS_SIZE  = 700;

/*
 * Processing Required
 */

int ys [] = {0, 100, 200, 300, 400, 500, 600};

public void
setup ()
{
    size(CANVAS_SIZE, CANVAS_SIZE);

    for (int i = 0; i < ys.length; ++i)
    {
        rect(20, ys[i] + 20 , 50, 50);    
    }
}

public void
draw ()
{   
    /* intentionally empty */
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page313" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
