import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page77 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 2b
 *
 * - 1 on page 41
 * - 3 on page 50
 * - 1 on page 59
 * - 1 on page 68
 * - 1 on page 77
 * - 1 on page 93
 * - 1 on page 99
 * - 1 on page 132
 *
 * page77.pde
 */

/*
Exercises
1. Use beginShape() to draw a shape of your own design.
*/

final int CANVAS_WIDTH  = 600;
final int CANVAS_HEIGHT = 500;

/*
 * Processing Required
 */

public void
setup ()
{
    size(CANVAS_WIDTH, CANVAS_HEIGHT);
    
    /* 1 */
    beginShape();
    vertex(100, 200);
    vertex(150, 300);
    vertex(200, 50);
    vertex(400, 450);
    vertex(100, 200);
    endShape();
}

public void
draw ()
{
    /* INTENTIONALLY EMPTY */
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page77" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
