import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page132 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 2b
 *
 * - 1 on page 41
 * - 3 on page 50
 * - 1 on page 59
 * - 1 on page 68
 * - 1 on page 77
 * - 1 on page 93
 * - 1 on page 99
 * - 1 on page 132
 *
 * page132.pde
 */

/*
Exercises
1. Use three variables assigned to random values to create a composition that is different every time the program is run.
*/

final int CANVAS_SIZE  = 500;

/*
 * Processing Required
 */
int s, x, y;

public void
setup ()
{
    size(CANVAS_SIZE, CANVAS_SIZE);
}

public void
draw ()
{
    s = (int)random(100, 400);
    x = (int)random(0, CANVAS_SIZE);
    y = (int)random(0, CANVAS_SIZE);
    ellipse(x, y, s, s);
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page132" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
