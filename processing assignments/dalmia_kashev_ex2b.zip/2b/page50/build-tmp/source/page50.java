import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page50 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 2b
 *
 * - 1 on page 41
 * - 3 on page 50
 * - 1 on page 59
 * - 1 on page 68
 * - 1 on page 77
 * - 1 on page 93
 * - 1 on page 99
 * - 1 on page 132
 *
 * page50.pde
 */

/*
Exercises
1. Use one variable to set the position and size for three ellipses.
2. Use multiplication to create a series of lines with increasing space between each.
3. Explore the functions for constraining numbers. Use min() and max() to draw a regular pattern of lines from a sequence of irregular numbers.
 */

final int CANVAS_WIDTH  = 700;
final int CANVAS_HEIGHT = 500;
/*
 * Processing Required
 */


public void
setup ()
{
    size(CANVAS_WIDTH, CANVAS_HEIGHT);
    
    /* 1 */
    final int s = 100;
    ellipse(s, s, s, s);
    ellipse(s, 2.5f*s, s, s);
    ellipse(s, 4*s, s, s);

    /* 2 */
    final int t = 200; final int b = 400;
    line(t, s, t, b);
    line(1.1f*t, s, 1.1f*t, b);
    line(1.7f*t, s, 1.7f*t, b);
    line(3*t, s, 3*t, b);

    /* 3 */

    final int [] values = { 129, 124, 42, 21, 100, 255, 124, 12, 141, 1600};

    line(min(values), min(values), 0.2f * max(values), 0.2f * max(values));
    line(0.2f * min(values), 2.0f * min(values), 0.2f * max(values), 0.2f * max(values));
    line(2.0f * min(values), 0.2f * min(values), 0.2f * max(values), 0.2f * max(values));

}

public void
draw ()
{

}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page50" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
