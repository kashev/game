import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class page180 extends PApplet {

/*
 * Kashev Dalmia    - dalmia3
 * ARTD 313 sp 2014 - Ex 2b
 * 3 on page 104
 * 1 on page 116
 * 1 on page 135
 * 1 on page 143
 * 1 on page 180
 * 3 on page 289
 * 
 * page180.pde
 */

/*
Exercises
1. Make a program run at four frames per second and display the current frame count to the console with println().
*/

final int CANVAS_SIZE  = 500;

/*
 * Processing Required
 */

int x = 0, y = 0, s = 50;
int vx = 2, vy = 4;

public void
setup ()
{
    size(CANVAS_SIZE, CANVAS_SIZE);
    frameRate(4);
}

public void
draw ()
{   
    background(0);
    rect(x, y, s, s);
    x += vx; y +=vy;

    if (x + s > CANVAS_SIZE || x < 0)
    {
        vx *= -1;
    }
    if (y + s > CANVAS_SIZE || y < 0)
    {
        vy *= -1;
    }
    println("frameRate: "+frameRate);
    frame.setTitle(frameRate + " fps");
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "page180" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
